jest.mock('../src/db', () => ({
  query: jest.fn(),
  init: jest.fn(),
  healthCheck: jest.fn(),
}));

const request = require('supertest');
const db = require('../src/db');
const createApp = require('../src/app');

describe('Items API', () => {
  const app = createApp();

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('GET /api/items returns list of items', async () => {
    db.query.mockResolvedValueOnce({
      rows: [{ id: 1, name: 'widget', created_at: new Date().toISOString() }],
    });

    const res = await request(app).get('/api/items');
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(1);
    expect(res.body[0].name).toBe('widget');
  });

  test('POST /api/items creates an item', async () => {
    db.query.mockResolvedValueOnce({
      rows: [{ id: 2, name: 'gadget', created_at: new Date().toISOString() }],
    });

    const res = await request(app).post('/api/items').send({ name: 'gadget' });
    expect(res.status).toBe(201);
    expect(res.body.name).toBe('gadget');
  });

  test('POST /api/items without name returns 400', async () => {
    const res = await request(app).post('/api/items').send({});
    expect(res.status).toBe(400);
    expect(db.query).not.toHaveBeenCalled();
  });

  test('GET /api/items handles DB errors gracefully', async () => {
    db.query.mockRejectedValueOnce(new Error('connection lost'));
    const res = await request(app).get('/api/items');
    expect(res.status).toBe(500);
  });
});
