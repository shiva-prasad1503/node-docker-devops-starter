const express = require('express');
const db = require('../db');

const router = express.Router();

router.get('/items', async (req, res, next) => {
  try {
    const { rows } = await db.query('SELECT id, name, created_at FROM items ORDER BY id DESC LIMIT 100');
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

router.post('/items', async (req, res, next) => {
  try {
    const { name } = req.body;
    if (!name || typeof name !== 'string') {
      return res.status(400).json({ error: 'name is required and must be a string' });
    }
    const { rows } = await db.query(
      'INSERT INTO items (name) VALUES ($1) RETURNING id, name, created_at',
      [name]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
