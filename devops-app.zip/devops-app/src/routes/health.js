const express = require('express');
const db = require('../db');
const cache = require('../cache');

const router = express.Router();

// Liveness: is the process up
router.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Readiness: are dependencies reachable
router.get('/ready', async (req, res) => {
  const checks = { db: false, redis: false };
  try {
    await db.healthCheck();
    checks.db = true;
  } catch (err) {
    req.log.warn({ err }, 'DB readiness check failed');
  }
  try {
    await cache.healthCheck();
    checks.redis = true;
  } catch (err) {
    req.log.warn({ err }, 'Redis readiness check failed');
  }

  const ready = checks.db && checks.redis;
  res.status(ready ? 200 : 503).json({ status: ready ? 'ready' : 'not_ready', checks });
});

module.exports = router;
