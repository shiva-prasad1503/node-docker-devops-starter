const express = require('express');
const pinoHttp = require('pino-http');

const logger = require('./logger');
const { register, metricsMiddleware } = require('./metrics');
const healthRoutes = require('./routes/health');
const itemsRoutes = require('./routes/items');
const errorHandler = require('./middleware/errorHandler');

function createApp() {
  const app = express();

  app.use(express.json());
  app.use(pinoHttp({ logger }));
  app.use(metricsMiddleware);

  app.use(healthRoutes);
  app.use('/api', itemsRoutes);

  app.get('/metrics', async (req, res) => {
    res.set('Content-Type', register.contentType);
    res.end(await register.metrics());
  });

  app.get('/', (req, res) => {
    res.json({ message: 'devops-app is running' });
  });

  app.use((req, res) => {
    res.status(404).json({ error: 'Not Found' });
  });

  app.use(errorHandler);

  return app;
}

module.exports = createApp;
