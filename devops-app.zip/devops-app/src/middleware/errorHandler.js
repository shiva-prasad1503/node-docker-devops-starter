// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  req.log?.error({ err }, 'Unhandled error');
  const status = err.status || 500;
  res.status(status).json({
    error: status === 500 ? 'Internal Server Error' : err.message,
  });
}

module.exports = errorHandler;
