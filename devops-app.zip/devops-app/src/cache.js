const { createClient } = require('redis');
const logger = require('./logger');

const client = createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379',
});

client.on('error', (err) => logger.error({ err }, 'Redis client error'));

let connected = false;

async function connect() {
  if (!connected) {
    await client.connect();
    connected = true;
  }
}

async function healthCheck() {
  await client.ping();
}

module.exports = { client, connect, healthCheck };
