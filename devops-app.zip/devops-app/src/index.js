require('dotenv').config();

const createApp = require('./app');
const logger = require('./logger');
const db = require('./db');
const cache = require('./cache');

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    await cache.connect();
    await db.init();
  } catch (err) {
    logger.warn({ err }, 'Startup dependency check failed; continuing (readiness probe will reflect status)');
  }

  const app = createApp();
  const server = app.listen(PORT, () => {
    logger.info(`Server listening on port ${PORT}`);
  });

  const shutdown = (signal) => {
    logger.info(`Received ${signal}, shutting down gracefully`);
    server.close(() => {
      logger.info('HTTP server closed');
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

start();
